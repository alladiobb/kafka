package com.masterdev.sbkafkaproducer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbKafkaProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
