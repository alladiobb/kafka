package com.masterdev.sbkafkaproducer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbKafkaProducerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbKafkaProducerApplication.class, args);
	}

}
